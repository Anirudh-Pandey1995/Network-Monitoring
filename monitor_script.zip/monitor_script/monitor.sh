#!/usr/bin/bash
echo scan_started_on >> /home/n_monitor/Desktop/monitor_script/log/monitor_log.txt
date +"%Y-%m-%d %H:%M:%S" >> /home/n_monitor/Desktop/monitor_script/log/monitor_log.txt
echo <n_monitor password> | sudo -S -u root nmap -A -p- -iL /home/n_monitor/Desktop/monitor_script/scope/ip.txt -oA /home/n_monitor/Desktop/monitor_script/scan_data/monitor
faraday-cli auth --faraday-url http://127.0.0.1:5985/login -u <faraday_user> -p <faraday_password>
faraday-cli workspace delete network
faraday-cli workspace create network
faraday-cli tool report -w network /home/n_monitor/Desktop/monitor_script/scan_data/monitor.xml
echo scan_finished_on >> /home/n_monitor/Desktop/monitor_script/log/monitor_log.txt
date +"%Y-%m-%d %H:%M:%S" >> /home/n_monitor/Desktop/monitor_script/log/monitor_log.txt

#backup  nmap data
cp /home/n_monitor/Desktop/monitor_script/scan_data/monitor.gnmap "/home/n_monitor/Desktop/monitor_script/Backup/monitor-$(date +"%m-%d-%y-%T").gnmap"
cp /home/n_monitor/Desktop/monitor_script/scan_data/monitor.xml "//home/n_monitor/Desktop/monitor_script/Backup/monitor-$(date +"%m-%d-%y-%T").xml"
cp /home/n_monitor/Desktop/monitor_script/scan_data/monitor.nmap "/home/n_monitor/Desktop/monitor_script/Backup/monitor-$(date +"%m-%d-%y-%T").nmap"

#create the csv from xml
python /home/n_monitor/Desktop/monitor_script/nmap_xml_parser.py -f /home/n_monitor/Desktop/monitor_script/scan_data/monitor.xml -csv /home/n_monitor/Desktop/monitor_script/ftp_portal/monitor.csv

#backup the csv
cp /home/n_monitor/Desktop/monitor_script/ftp_portal/monitor.csv "/home/n_monitor/Desktop/monitor_script/Backup/monitor-$(date +"%m-%d-%y-%T").csv"

#convert the csv to excel
rm /home/n_monitor/Desktop/monitor_script/ftp_portal/scan_xls/*.xlsx
python /home/n_monitor/Desktop/monitor_script/converter.py


#extact screenshots web screenshots
rm -rf /home/n_monitor/Desktop/monitor_script/ftp_portal/web_screenshots
python /home/n_monitor/Desktop/monitor_script/EyeWitness-master/Python/web_screenshot.py -x /home/n_monitor/Desktop/monitor_script/scan_data/monitor.xml -d /home/n_monitor/Desktop/monitor_script/ftp_portal/web_screenshots --no-prompt

pandoc -i /home/n_monitor/Desktop/monitor_script/ftp_portal/web_screenshots/*.html -o /home/n_monitor/Desktop/monitor_script/ftp_portal/web_screenshots/output.html

#backup of web screenshot
cp -R /home/n_monitor/Desktop/monitor_script/ftp_portal/web_screenshots "/home/n_monitor/Desktop/monitor_script/Backup/web-$(date +"%m-%d-%y-%T")"


#cleanup
rm /home/n_monitor/Desktop/monitor_script/*.txt
rm /home/n_monitor/Desktop/monitor_script/ftp_portal/*.csv
echo <n_monitor password> | sudo -S -u root rm /home/n_monitor/Desktop/monitor_script/scan_data/*.nmap
echo <n_monitor password> | sudo -S -u root rm /home/n_monitor/Desktop/monitor_script/scan_data/*.gnmap
echo <n_monitor password> | sudo -S -u root rm /home/n_monitor/Desktop/monitor_script/scan_data/*.xml
